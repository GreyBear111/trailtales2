// src/test/java/com/trailtales/repository/LocationRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Location;
import com.trailtales.repository.LocationRepository;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class)
@Transactional
@DisplayName("Тести для LocationRepository")
class LocationRepositoryTest {

  @Autowired private LocationRepository locationRepository;

  @Autowired private DataSource dataSource;

  // ID локації, створеної в setUp
  private Long locationKyivId;
  private String locationKyivName = "Київ, Україна";

  @BeforeEach
  void setUp() throws SQLException, IOException {
    // 1. Очищення та створення схеми
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {
      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);
    }

    // 2. Програмне створення ДАНИХ для тестів Location
    // (Можна було б залишити dml.sql, але для простоти і контролю створимо тут)
    Location kyiv = new Location(null, locationKyivName, "Столиця України", null, null);
    locationKyivId = locationRepository.save(kyiv).getId();

    Location lviv = new Location(null, "Львів, Україна", "Культурна столиця", null, null);
    locationRepository.save(lviv);
  }

  @Test
  @DisplayName("Повинен зберігати нову локацію і знаходити її за ID")
  void testSaveAndFindById_NewLocation() {
    // Given
    Location newLocation = new Location();
    newLocation.setName("Харків, Україна");
    newLocation.setDescription("Науковий центр");

    // When
    Location savedLocation = locationRepository.save(newLocation);
    Optional<Location> foundLocationOpt = locationRepository.findById(savedLocation.getId());

    // Then
    assertNotNull(savedLocation.getId(), "ID не повинен бути null після збереження");
    assertTrue(foundLocationOpt.isPresent(), "Збережена локація має бути знайдена за ID");
    Location foundLocation = foundLocationOpt.get();
    assertEquals("Харків, Україна", foundLocation.getName());
    assertEquals("Науковий центр", foundLocation.getDescription());
  }

  @Test
  @DisplayName("Повинен знаходити локацію за назвою")
  void testFindByName() {
    // When
    Optional<Location> foundLocationOpt = locationRepository.findByName(locationKyivName);

    // Then
    assertTrue(foundLocationOpt.isPresent(), "Локація 'Київ, Україна' має бути знайдена");
    assertEquals(locationKyivId, foundLocationOpt.get().getId());
  }

  @Test
  @DisplayName("Повинен повертати порожній Optional для неіснуючої назви")
  void testFindByName_NotFound() {
    // When
    Optional<Location> notFoundOpt = locationRepository.findByName("Неіснуюче Місто");

    // Then
    assertFalse(notFoundOpt.isPresent(), "Для неіснуючої назви має повертатися порожній Optional");
  }

  @Test
  @DisplayName("Повинен оновлювати існуючу локацію")
  void testUpdateLocation() {
    // Given
    Location locationToUpdate = locationRepository.findById(locationKyivId).orElseThrow();
    locationToUpdate.setName("Київ - Столиця України (оновлено)");
    locationToUpdate.setDescription("Оновлений опис столиці.");

    // When
    locationRepository.save(locationToUpdate);
    Location updatedLocation = locationRepository.findById(locationKyivId).orElseThrow();

    // Then
    assertEquals("Київ - Столиця України (оновлено)", updatedLocation.getName());
    assertEquals("Оновлений опис столиці.", updatedLocation.getDescription());
  }

  @Test
  @DisplayName("Повинен знаходити всі локації")
  void testFindAll() {
    // Given
    // У setUp вже створено дві локації. Створимо ще одну.
    locationRepository.save(new Location(null, "Дніпро, Україна", "Промисловий центр", null, null));

    // When
    List<Location> allLocations = locationRepository.findAll();

    // Then
    assertEquals(3, allLocations.size(), "Має бути знайдено 3 локації");
  }

  @Test
  @DisplayName("Повинен видаляти локацію за ID")
  void testDeleteById() {
    // Given
    Long locationIdToDelete = locationKyivId; // Локація, створена в setUp

    // When
    locationRepository.deleteById(locationIdToDelete);
    Optional<Location> deletedLocationOpt = locationRepository.findById(locationIdToDelete);

    // Then
    assertFalse(deletedLocationOpt.isPresent(), "Локація має бути видалена з бази даних");
  }
}
