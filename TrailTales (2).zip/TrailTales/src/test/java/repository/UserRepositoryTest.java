// src/test/java/com/trailtales/repository/UserRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Role;
import com.trailtales.entity.RoleName;
import com.trailtales.entity.User;
import com.trailtales.repository.RoleRepository;
import com.trailtales.repository.UserRepository;
import com.trailtales.util.PasswordHasher;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class)
@Transactional
@DisplayName("Тести для UserRepository")
class UserRepositoryTest {

  @Autowired private UserRepository userRepository;

  @Autowired private RoleRepository roleRepository; // Потрібен для роботи з ролями

  @Autowired private DataSource dataSource;

  // Створимо екземпляр PasswordHasher, оскільки він не є частиною Spring Context у тестах
  private final PasswordHasher passwordHasher = new PasswordHasher();

  @BeforeEach
  void setUp() throws SQLException, IOException {
    // Ідеально чистий стан перед кожним тестом
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {

      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);

      Resource dmlResource = new ClassPathResource("dml.sql");
      String dmlScript = dmlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(dmlScript);
    }
  }

  @Test
  @DisplayName("Повинен зберігати нового користувача і знаходити його за ID")
  void testSaveAndFindById_NewUser() {
    // Given
    User newUser = new User();
    newUser.setUsername("new_test_user");
    newUser.setEmail("new.test@example.com");
    newUser.setPasswordHash(passwordHasher.hashPassword("password123"));

    Role userRole = roleRepository.findByName(RoleName.ROLE_USER).orElseThrow();
    newUser.addRole(userRole);

    // When
    User savedUser = userRepository.save(newUser);

    // Then
    assertNotNull(savedUser.getId(), "ID не повинен бути null після збереження");
    Optional<User> foundUserOpt = userRepository.findById(savedUser.getId());

    assertTrue(foundUserOpt.isPresent(), "Збережений користувач має бути знайдений за ID");
    User foundUser = foundUserOpt.get();
    assertEquals("new_test_user", foundUser.getUsername());
    assertFalse(foundUser.getRoles().isEmpty(), "Ролі користувача не повинні бути порожніми");
    assertEquals(
        RoleName.ROLE_USER,
        foundUser.getRoles().iterator().next().getName(),
        "Користувач повинен мати роль ROLE_USER");
  }

  @Test
  @DisplayName("Повинен оновлювати існуючого користувача")
  void testUpdateUser() {
    // Given
    User userToUpdate = userRepository.findByUsername("test_user").orElseThrow();
    userToUpdate.setUsername("test_user_updated");
    userToUpdate.setEmail("updated.email@example.com");

    // When
    userRepository.save(userToUpdate);
    Optional<User> updatedUserOpt = userRepository.findById(userToUpdate.getId());

    // Then
    assertTrue(updatedUserOpt.isPresent());
    assertEquals("test_user_updated", updatedUserOpt.get().getUsername());
    assertEquals("updated.email@example.com", updatedUserOpt.get().getEmail());
  }

  @Test
  @DisplayName("Повинен знаходити всіх користувачів")
  void testFindAll() {
    // When
    List<User> allUsers = userRepository.findAll();

    // Then
    // У вашому dml.sql 3 користувачі
    assertEquals(3, allUsers.size(), "Кількість користувачів повинна відповідати даним у dml.sql");
  }

  @Test
  @DisplayName("Повинен знаходити користувача за ім'ям")
  void testFindByUsername() {
    // When
    Optional<User> foundUserOpt = userRepository.findByUsername("admin_user");

    // Then
    assertTrue(foundUserOpt.isPresent());
    assertEquals("admin@example.com", foundUserOpt.get().getEmail());
  }

  @Test
  @DisplayName("Повинен знаходити користувача за email")
  void testFindByEmail() {
    // When
    Optional<User> foundUserOpt = userRepository.findByEmail("jane.doe@example.com");

    // Then
    assertTrue(foundUserOpt.isPresent());
    assertEquals("jane_doe", foundUserOpt.get().getUsername());
  }

  @Test
  @DisplayName("Повинен видаляти користувача за ID")
  void testDeleteById() {
    // Given
    User userToDelete = userRepository.findByUsername("jane_doe").orElseThrow();
    Long userId = userToDelete.getId();

    // When
    userRepository.deleteById(userId);
    Optional<User> deletedUserOpt = userRepository.findById(userId);

    // Then
    assertFalse(deletedUserOpt.isPresent(), "Користувач має бути видалений з бази даних");
  }

  @Test
  @DisplayName("Повинен правильно оновлювати ролі користувача")
  void testUpdateUserRoles() {
    // Given
    // "admin_user" за замовчуванням має ROLE_ADMIN та ROLE_USER
    User adminUser = userRepository.findByUsername("admin_user").orElseThrow();
    assertEquals(2, adminUser.getRoles().size(), "Спочатку адмін має 2 ролі");

    // Залишаємо адміну тільки одну роль
    Role userRole = roleRepository.findByName(RoleName.ROLE_USER).orElseThrow();
    adminUser.getRoles().clear();
    adminUser.addRole(userRole);

    // When
    userRepository.save(adminUser);
    User updatedAdmin = userRepository.findById(adminUser.getId()).orElseThrow();

    // Then
    assertEquals(1, updatedAdmin.getRoles().size(), "Після оновлення адмін має мати 1 роль");
    assertEquals(RoleName.ROLE_USER, updatedAdmin.getRoles().iterator().next().getName());
  }
}
