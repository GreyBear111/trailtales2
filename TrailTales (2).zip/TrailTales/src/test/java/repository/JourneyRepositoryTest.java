// src/test/java/com/trailtales/repository/JourneyRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Journey;
import com.trailtales.entity.Location;
import com.trailtales.entity.Role;
import com.trailtales.entity.RoleName;
import com.trailtales.entity.Tag;
import com.trailtales.entity.User;
import com.trailtales.repository.*;
import com.trailtales.util.PasswordHasher; // Потрібен для створення User
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class)
@Transactional
@DisplayName("Тести для JourneyRepository")
class JourneyRepositoryTest {

  @Autowired private JourneyRepository journeyRepository;
  @Autowired private UserRepository userRepository;
  @Autowired private LocationRepository locationRepository;
  @Autowired private TagRepository tagRepository;
  @Autowired private RoleRepository roleRepository; // Потрібен для створення User
  @Autowired private DataSource dataSource;

  private PasswordHasher passwordHasher = new PasswordHasher();

  // Збережемо ID створених сутностей, щоб використовувати їх у тестах
  private Long userIdTestUser;
  private Long userIdJaneDoe;
  private Long userIdAdmin;
  private Long locationKyivId;
  private Long locationLvivId;
  private Long locationCarpathiansId;
  private Long locationOdesaId;
  private Long tagMountainsId;
  private Long tagSeaId;
  private Long tagCityId;
  private Long journeyCarpatiansHikeId;
  private Long journeyOdesaVacationId;

  @BeforeEach
  void setUp() throws SQLException, IOException {
    // 1. Очищення та створення схеми
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {
      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);
    }

    // 2. Програмне створення необхідних ДАНИХ замість виконання dml.sql
    // Ролі (якщо їх немає, ddl.sql має їх створити, але перестрахуємось)
    Role roleUser =
        roleRepository
            .findByName(RoleName.ROLE_USER)
            .orElseGet(() -> roleRepository.save(new Role(null, RoleName.ROLE_USER, null, null)));
    Role roleAdmin =
        roleRepository
            .findByName(RoleName.ROLE_ADMIN)
            .orElseGet(() -> roleRepository.save(new Role(null, RoleName.ROLE_ADMIN, null, null)));

    // Користувачі
    User adminUser =
        new User(
            null,
            "admin_user",
            "admin@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleAdmin, roleUser)));
    userIdAdmin = userRepository.save(adminUser).getId();

    User testUser =
        new User(
            null,
            "test_user",
            "user@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleUser)));
    userIdTestUser = userRepository.save(testUser).getId();

    User janeDoe =
        new User(
            null,
            "jane_doe",
            "jane.doe@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleUser)));
    userIdJaneDoe = userRepository.save(janeDoe).getId();

    // Локації
    Location kyiv =
        locationRepository.save(new Location(null, "Київ, Україна", "Столиця", null, null));
    locationKyivId = kyiv.getId();
    Location lviv =
        locationRepository.save(
            new Location(null, "Львів, Україна", "Культурна столиця", null, null));
    locationLvivId = lviv.getId();
    Location carpathians =
        locationRepository.save(new Location(null, "Карпати, Україна", "Гори", null, null));
    locationCarpathiansId = carpathians.getId();
    Location odesa =
        locationRepository.save(new Location(null, "Одеса, Україна", "Море", null, null));
    locationOdesaId = odesa.getId();

    // Теги
    Tag tagActive = tagRepository.save(new Tag(null, "Активний відпочинок", null, null));
    Tag tagMountains = tagRepository.save(new Tag(null, "Гори", null, null));
    tagMountainsId = tagMountains.getId();
    Tag tagSea = tagRepository.save(new Tag(null, "Море", null, null));
    tagSeaId = tagSea.getId();
    Tag tagCity = tagRepository.save(new Tag(null, "Місто", null, null));
    tagCityId = tagCity.getId();

    // Подорожі
    Journey carpatiansHike = new Journey();
    carpatiansHike.setUserId(userIdTestUser);
    carpatiansHike.setName("Похід в Карпати");
    carpatiansHike.setDescription("Тижневий похід по Чорногірському хребту.");
    carpatiansHike.setStartDate(LocalDate.of(2024, 7, 10));
    carpatiansHike.setEndDate(LocalDate.of(2024, 7, 17));
    carpatiansHike.setOriginLocationId(locationKyivId);
    carpatiansHike.setDestinationLocationId(locationCarpathiansId);
    carpatiansHike.setTags(new HashSet<>(Set.of(tagActive, tagMountains)));
    carpatiansHike.setParticipants(
        new HashSet<>(Set.of(userRepository.findById(userIdAdmin).get()))); // Адмін - учасник
    journeyCarpatiansHikeId = journeyRepository.save(carpatiansHike).getId();

    Journey odesaVacation = new Journey();
    odesaVacation.setUserId(userIdJaneDoe);
    odesaVacation.setName("Відпочинок на морі в Одесі");
    odesaVacation.setDescription("Тиждень на узбережжі Чорного моря.");
    odesaVacation.setStartDate(LocalDate.of(2024, 8, 1));
    odesaVacation.setEndDate(LocalDate.of(2024, 8, 8));
    odesaVacation.setOriginLocationId(locationLvivId);
    odesaVacation.setDestinationLocationId(locationOdesaId);
    odesaVacation.setTags(new HashSet<>(Set.of(tagSea)));
    journeyOdesaVacationId = journeyRepository.save(odesaVacation).getId();
  }

  @Test
  @DisplayName("Повинен зберігати нову подорож з тегами і знаходити її за ID")
  void testSaveAndFindById_NewJourney() {
    // Given
    User owner = userRepository.findById(userIdTestUser).orElseThrow();
    Location origin = locationRepository.findById(locationKyivId).orElseThrow();
    Location destination = locationRepository.findById(locationLvivId).orElseThrow();
    Tag tag = tagRepository.findById(tagCityId).orElseThrow();

    Journey newJourney = new Journey();
    newJourney.setUserId(owner.getId());
    newJourney.setName("Нова Подорож до Львова");
    newJourney.setDescription("Тестова подорож");
    newJourney.setStartDate(LocalDate.of(2025, 6, 1));
    newJourney.setEndDate(LocalDate.of(2025, 6, 5));
    newJourney.setOriginLocationId(origin.getId());
    newJourney.setDestinationLocationId(destination.getId());
    newJourney.setTags(Set.of(tag));

    // When
    Journey savedJourney = journeyRepository.save(newJourney);
    Optional<Journey> foundJourneyOpt = journeyRepository.findById(savedJourney.getId());

    // Then
    assertTrue(foundJourneyOpt.isPresent(), "Збережена подорож має бути знайдена");
    Journey foundJourney = foundJourneyOpt.get();
    assertEquals("Нова Подорож до Львова", foundJourney.getName());
    assertEquals(owner.getId(), foundJourney.getUserId());
    assertNotNull(foundJourney.getTags(), "Список тегів не повинен бути null");
    assertFalse(foundJourney.getTags().isEmpty(), "Список тегів не повинен бути порожнім");
    assertTrue(
        foundJourney.getTags().stream().anyMatch(t -> t.getId().equals(tagCityId)),
        "Подорож повинна мати тег 'Місто'");
  }

  @Test
  @DisplayName("Повинен оновлювати назву і опис існуючої подорожі")
  void testUpdateJourney() {
    // Given
    Journey journeyToUpdate = journeyRepository.findById(journeyCarpatiansHikeId).orElseThrow();
    journeyToUpdate.setName("Похід в Карпати (оновлено)");
    journeyToUpdate.setDescription("Супер оновлений опис походу.");

    // When
    journeyRepository.save(journeyToUpdate);
    Journey updatedJourney = journeyRepository.findById(journeyToUpdate.getId()).orElseThrow();

    // Then
    assertEquals("Похід в Карпати (оновлено)", updatedJourney.getName());
    assertEquals("Супер оновлений опис походу.", updatedJourney.getDescription());
  }

  @Test
  @DisplayName("Повинен знаходити всі подорожі, створені певним користувачем")
  void testFindByUserId() {
    // Given
    // userIdJaneDoe має одну подорож "Відпочинок на морі в Одесі"
    // When
    List<Journey> journeys = journeyRepository.findByUserId(userIdJaneDoe);

    // Then
    assertNotNull(journeys, "Список подорожей не повинен бути null");
    assertEquals(1, journeys.size(), "Користувач 'jane.doe' повинен мати 1 подорож");
    assertEquals("Відпочинок на морі в Одесі", journeys.get(0).getName());
  }

  @Test
  @DisplayName("Повинен знаходити подорожі, в яких користувач є учасником")
  void testFindByParticipantId() {
    // Given
    // userIdAdmin є учасником в "Похід в Карпати"
    // When
    List<Journey> journeys = journeyRepository.findByParticipantId(userIdAdmin);

    // Then
    assertEquals(1, journeys.size());
    assertEquals("Похід в Карпати", journeys.get(0).getName());
  }

  @Test
  @DisplayName("Повинен видаляти подорож за ID")
  void testDeleteById() {
    // Given
    Long journeyIdToDelete = journeyOdesaVacationId;

    // When
    journeyRepository.deleteById(journeyIdToDelete);
    Optional<Journey> deletedJourneyOpt = journeyRepository.findById(journeyIdToDelete);

    // Then
    assertFalse(deletedJourneyOpt.isPresent(), "Подорож має бути видалена");
  }

  @Test
  @DisplayName("Повинен додавати та видаляти учасника подорожі")
  void testAddAndRemoveParticipant() {
    // Given
    Journey journey = journeyRepository.findById(journeyOdesaVacationId).orElseThrow();
    User newParticipant = userRepository.findById(userIdTestUser).orElseThrow();

    // When (Add)
    journeyRepository.addParticipant(journey.getId(), newParticipant.getId());
    Set<User> participantsAfterAdd = journeyRepository.findParticipantsByJourneyId(journey.getId());

    // Then (Add)
    assertTrue(
        participantsAfterAdd.stream().anyMatch(p -> p.getId().equals(newParticipant.getId())),
        "Новий учасник має бути у списку");

    // When (Remove)
    journeyRepository.removeParticipant(journey.getId(), newParticipant.getId());
    Set<User> participantsAfterRemove =
        journeyRepository.findParticipantsByJourneyId(journey.getId());

    // Then (Remove)
    assertFalse(
        participantsAfterRemove.stream().anyMatch(p -> p.getId().equals(newParticipant.getId())),
        "Новий учасник має бути видалений зі списку");
  }

  @Test
  @DisplayName("Повинен знаходити подорожі за ключовим словом в назві або описі")
  void testSearchJourneys() {
    // When
    List<Journey> foundByDescription = journeyRepository.searchJourneys("Чорногірському");
    List<Journey> foundByName = journeyRepository.searchJourneys("Одесі");

    // Then
    assertEquals(1, foundByDescription.size());
    assertEquals("Похід в Карпати", foundByDescription.get(0).getName());

    assertEquals(1, foundByName.size());
    assertEquals("Відпочинок на морі в Одесі", foundByName.get(0).getName());
  }
}
