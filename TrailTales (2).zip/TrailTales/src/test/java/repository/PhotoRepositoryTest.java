// src/test/java/com/trailtales/repository/PhotoRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Journey;
import com.trailtales.entity.Location;
import com.trailtales.entity.Photo;
import com.trailtales.entity.Role;
import com.trailtales.entity.RoleName;
import com.trailtales.entity.Tag;
import com.trailtales.entity.User;
import com.trailtales.repository.*;
import com.trailtales.util.PasswordHasher;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class)
@Transactional
@DisplayName("Тести для PhotoRepository")
class PhotoRepositoryTest {

  @Autowired private PhotoRepository photoRepository;
  @Autowired private JourneyRepository journeyRepository;
  @Autowired private UserRepository userRepository;
  @Autowired private LocationRepository locationRepository;
  @Autowired private TagRepository tagRepository;
  @Autowired private RoleRepository roleRepository;
  @Autowired private DataSource dataSource;

  private PasswordHasher passwordHasher = new PasswordHasher();

  // ID сутностей, створених у setUp
  private Long userIdTestUser;
  private Long journeyCarpatiansHikeId;

  // Можна додати ID інших сутностей, якщо вони потрібні для фото

  @BeforeEach
  void setUp() throws SQLException, IOException {
    // 1. Очищення та створення схеми
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {
      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);
    }

    // 2. Програмне створення необхідних ДАНИХ
    Role roleUser =
        roleRepository
            .findByName(RoleName.ROLE_USER)
            .orElseGet(() -> roleRepository.save(new Role(null, RoleName.ROLE_USER, null, null)));
    Role roleAdmin =
        roleRepository
            .findByName(RoleName.ROLE_ADMIN)
            .orElseGet(() -> roleRepository.save(new Role(null, RoleName.ROLE_ADMIN, null, null)));

    User adminUser =
        new User(
            null,
            "admin_user",
            "admin@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleAdmin, roleUser)));
    userRepository.save(adminUser);

    User testUser =
        new User(
            null,
            "test_user",
            "user@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleUser)));
    userIdTestUser = userRepository.save(testUser).getId();

    User janeDoe =
        new User(
            null,
            "jane_doe",
            "jane.doe@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleUser)));
    userRepository.save(janeDoe);

    Location kyiv =
        locationRepository.save(new Location(null, "Київ, Україна", "Столиця", null, null));
    Location carpathians =
        locationRepository.save(new Location(null, "Карпати, Україна", "Гори", null, null));

    Tag tagActive = tagRepository.save(new Tag(null, "Активний відпочинок", null, null));
    Tag tagMountains = tagRepository.save(new Tag(null, "Гори", null, null));

    Journey carpatiansHike = new Journey();
    carpatiansHike.setUserId(userIdTestUser);
    carpatiansHike.setName("Похід в Карпати");
    carpatiansHike.setStartDate(LocalDate.of(2024, 7, 10));
    carpatiansHike.setOriginLocationId(kyiv.getId());
    carpatiansHike.setDestinationLocationId(carpathians.getId());
    carpatiansHike.setTags(new HashSet<>(Set.of(tagActive, tagMountains)));
    journeyCarpatiansHikeId = journeyRepository.save(carpatiansHike).getId();
  }

  @Test
  @DisplayName("Повинен зберігати нове фото і знаходити його за ID")
  void testSaveAndFindById_NewPhoto() {
    // Given
    Photo newPhoto = new Photo();
    newPhoto.setJourneyId(journeyCarpatiansHikeId);
    newPhoto.setUserId(userIdTestUser);
    newPhoto.setFilePath("./uploads/test_photo_01.jpg");
    newPhoto.setDescription("Перше тестове фото");

    // When
    Photo savedPhoto = photoRepository.save(newPhoto);
    Optional<Photo> foundPhotoOpt = photoRepository.findById(savedPhoto.getId());

    // Then
    assertNotNull(savedPhoto.getId(), "ID не повинен бути null після збереження");
    assertTrue(foundPhotoOpt.isPresent(), "Збережене фото має бути знайдене за ID");
    Photo foundPhoto = foundPhotoOpt.get();
    assertEquals(journeyCarpatiansHikeId, foundPhoto.getJourneyId());
    assertEquals(userIdTestUser, foundPhoto.getUserId());
    assertEquals("./uploads/test_photo_01.jpg", foundPhoto.getFilePath());
    assertEquals("Перше тестове фото", foundPhoto.getDescription());
  }

  @Test
  @DisplayName("Повинен оновлювати опис існуючого фото")
  void testUpdatePhotoDescription() {
    // Given
    Photo photoToUpdate = new Photo();
    photoToUpdate.setJourneyId(journeyCarpatiansHikeId);
    photoToUpdate.setUserId(userIdTestUser);
    photoToUpdate.setFilePath("./uploads/photo_to_update.jpg");
    photoToUpdate.setDescription("Початковий опис");
    photoToUpdate = photoRepository.save(photoToUpdate); // Зберігаємо і отримуємо ID

    photoToUpdate.setDescription("Оновлений опис фото");

    // When
    photoRepository.save(photoToUpdate); // Зберігаємо з оновленим описом
    Photo updatedPhoto = photoRepository.findById(photoToUpdate.getId()).orElseThrow();

    // Then
    assertEquals("Оновлений опис фото", updatedPhoto.getDescription());
    assertEquals(
        "./uploads/photo_to_update.jpg",
        updatedPhoto.getFilePath()); // Перевіряємо, що інші поля не змінились
  }

  @Test
  @DisplayName("Повинен знаходити всі фотографії для певної подорожі")
  void testFindByJourneyId() {
    // Given
    Photo photo1 =
        new Photo(
            null,
            journeyCarpatiansHikeId,
            userIdTestUser,
            "./uploads/hike_photo1.jpg",
            "Фото 1 з походу",
            null,
            null);
    Photo photo2 =
        new Photo(
            null,
            journeyCarpatiansHikeId,
            userIdTestUser,
            "./uploads/hike_photo2.jpg",
            "Фото 2 з походу",
            null,
            null);
    photoRepository.save(photo1);
    photoRepository.save(photo2);

    // Створимо ще одну подорож та фото для неї, щоб перевірити фільтрацію
    Journey otherJourney = new Journey();
    otherJourney.setUserId(userIdTestUser);
    otherJourney.setName("Інша подорож");
    otherJourney = journeyRepository.save(otherJourney);
    Photo photo3 =
        new Photo(
            null,
            otherJourney.getId(),
            userIdTestUser,
            "./uploads/other_photo.jpg",
            "Фото з іншої подорожі",
            null,
            null);
    photoRepository.save(photo3);

    // When
    List<Photo> photosForHike = photoRepository.findByJourneyId(journeyCarpatiansHikeId);

    // Then
    assertEquals(2, photosForHike.size(), "Має бути знайдено 2 фото для походу в Карпати");
    assertTrue(
        photosForHike.stream().anyMatch(p -> "./uploads/hike_photo1.jpg".equals(p.getFilePath())));
    assertTrue(
        photosForHike.stream().anyMatch(p -> "./uploads/hike_photo2.jpg".equals(p.getFilePath())));
  }

  @Test
  @DisplayName("Повинен видаляти фото за ID")
  void testDeleteById() {
    // Given
    Photo photoToDelete =
        new Photo(
            null,
            journeyCarpatiansHikeId,
            userIdTestUser,
            "./uploads/photo_to_delete.jpg",
            "Фото для видалення",
            null,
            null);
    photoToDelete = photoRepository.save(photoToDelete);
    Long photoId = photoToDelete.getId();

    // When
    photoRepository.deleteById(photoId);
    Optional<Photo> deletedPhotoOpt = photoRepository.findById(photoId);

    // Then
    assertFalse(deletedPhotoOpt.isPresent(), "Фото має бути видалене з бази даних");
  }
}
