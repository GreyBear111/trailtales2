// src/test/java/com/trailtales/repository/TagRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Tag;
import com.trailtales.repository.TagRepository;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class) // Використовуємо основну конфігурацію
@Transactional // Кожен тест виконується у своїй транзакції, яка відкочується після завершення
@DisplayName("Тести для TagRepository")
class TagRepositoryTest {

  @Autowired private TagRepository tagRepository;

  @Autowired private DataSource dataSource; // Інжектуємо DataSource для ініціалізації

  @BeforeEach
  void setUp() throws SQLException, IOException {
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {

      // 1. Повністю очищуємо всі таблиці перед кожним тестом.
      // TRUNCATE ... CASCADE швидко видаляє всі дані та скидає лічильники ID,
      // ігноруючи обмеження зовнішніх ключів.
      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      // 2. Виконуємо ddl.sql для створення схеми (якщо раптом її немає)
      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);

      // 3. Заповнюємо базу свіжими даними з dml.sql
      Resource dmlResource = new ClassPathResource("dml.sql");
      String dmlScript = dmlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(dmlScript);
    }
  }

  @Test
  @DisplayName("Повинен зберігати новий тег і знаходити його за ID")
  void testSaveAndFindById() {
    // Given
    Tag newTag = new Tag();
    newTag.setName("Новий Унікальний Тег");

    // When
    Tag savedTag = tagRepository.save(newTag);

    // Then
    assertNotNull(savedTag.getId(), "ID не повинен бути null після збереження");
    Optional<Tag> foundTagOpt = tagRepository.findById(savedTag.getId());
    assertTrue(foundTagOpt.isPresent(), "Збережений тег має бути знайдений за ID");
    assertEquals(
        "Новий Унікальний Тег", foundTagOpt.get().getName(), "Назви тегів повинні співпадати");
  }

  @Test
  @DisplayName("Повинен знаходити всі теги")
  void testFindAll() {
    // When
    List<Tag> allTags = tagRepository.findAll();

    // Then
    // У вашому dml.sql 6 тегів
    assertFalse(allTags.isEmpty(), "Список тегів не повинен бути порожнім");
    assertEquals(6, allTags.size(), "Кількість тегів повинна відповідати даним у dml.sql");
  }

  @Test
  @DisplayName("Повинен оновлювати існуючий тег")
  void testUpdate() {
    // Given
    // Беремо перший тег з dml.sql - 'Активний відпочинок'
    Optional<Tag> tagToUpdateOpt = tagRepository.findByName("Активний відпочинок");
    assertTrue(tagToUpdateOpt.isPresent(), "Тег для оновлення має існувати");
    Tag tagToUpdate = tagToUpdateOpt.get();
    tagToUpdate.setName("Супер Активний Відпочинок");

    // When
    tagRepository.save(tagToUpdate);
    Optional<Tag> updatedTagOpt = tagRepository.findById(tagToUpdate.getId());

    // Then
    assertTrue(updatedTagOpt.isPresent(), "Оновлений тег має бути знайдений");
    assertEquals(
        "Супер Активний Відпочинок", updatedTagOpt.get().getName(), "Назва тегу має бути оновлена");
  }

  @Test
  @DisplayName("Повинен видаляти тег за ID")
  void testDeleteById() {
    // Given
    Optional<Tag> tagToDeleteOpt = tagRepository.findByName("Гори");
    assertTrue(tagToDeleteOpt.isPresent(), "Тег для видалення має існувати");
    Long tagId = tagToDeleteOpt.get().getId();

    // When
    tagRepository.deleteById(tagId);
    Optional<Tag> deletedTagOpt = tagRepository.findById(tagId);

    // Then
    assertFalse(deletedTagOpt.isPresent(), "Тег має бути видалений з бази даних");
  }

  @Test
  @DisplayName("Повинен повертати порожній Optional для неіснуючого ID")
  void testFindById_NotFound() {
    // When
    Optional<Tag> notFoundTag = tagRepository.findById(9999L);

    // Then
    assertTrue(notFoundTag.isEmpty(), "Для неіснуючого ID повинен повертатись порожній Optional");
  }
}
