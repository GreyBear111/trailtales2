// src/test/java/com/trailtales/repository/EventRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Event;
import com.trailtales.entity.Journey;
import com.trailtales.entity.Location;
import com.trailtales.entity.Role;
import com.trailtales.entity.RoleName;
import com.trailtales.entity.User;
import com.trailtales.repository.*;
import com.trailtales.util.PasswordHasher;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class)
@Transactional
@DisplayName("Тести для EventRepository")
class EventRepositoryTest {

  @Autowired private EventRepository eventRepository;
  @Autowired private JourneyRepository journeyRepository;
  @Autowired private UserRepository userRepository;
  @Autowired private LocationRepository locationRepository;
  @Autowired private RoleRepository roleRepository;

  @Autowired
  private TagRepository tagRepository; // Хоча прямо не використовується для Event, але є в setUp

  @Autowired private DataSource dataSource;

  private PasswordHasher passwordHasher = new PasswordHasher();

  // ID сутностей, створених у setUp, для використання в тестах
  private Long userIdTestUser;
  private Long journeyCarpatiansHikeId;
  private Long locationCarpathiansId;
  private Long eventGoverlaAscentId; // Для одного з тестових івентів

  @BeforeEach
  void setUp() throws SQLException, IOException {
    // 1. Очищення та створення схеми
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {
      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);
    }

    // 2. Програмне створення необхідних ДАНИХ
    Role roleUser =
        roleRepository
            .findByName(RoleName.ROLE_USER)
            .orElseGet(() -> roleRepository.save(new Role(null, RoleName.ROLE_USER, null, null)));

    User testUser =
        new User(
            null,
            "test_user",
            "user@example.com",
            passwordHasher.hashPassword("password"),
            null,
            null,
            new HashSet<>(Set.of(roleUser)));
    userIdTestUser = userRepository.save(testUser).getId();

    Location kyiv =
        locationRepository.save(new Location(null, "Київ, Україна", "Столиця", null, null));
    Location carpathians =
        locationRepository.save(new Location(null, "Карпати, Україна", "Гори", null, null));
    locationCarpathiansId = carpathians.getId();

    Journey carpatiansHike = new Journey();
    carpatiansHike.setUserId(userIdTestUser);
    carpatiansHike.setName("Похід в Карпати");
    carpatiansHike.setStartDate(LocalDate.of(2024, 7, 10));
    carpatiansHike.setOriginLocationId(kyiv.getId());
    carpatiansHike.setDestinationLocationId(locationCarpathiansId);
    journeyCarpatiansHikeId = journeyRepository.save(carpatiansHike).getId();

    // Створимо один івент у setUp для тесту findAll та інших
    Event goverlaAscent = new Event();
    goverlaAscent.setJourneyId(journeyCarpatiansHikeId);
    goverlaAscent.setLocationId(locationCarpathiansId);
    goverlaAscent.setName("Сходження на Говерлу");
    goverlaAscent.setDescription("Підкорення найвищої точки України.");
    goverlaAscent.setEventDate(LocalDate.of(2024, 7, 12));
    goverlaAscent.setEventTime(LocalTime.of(8, 0));
    eventGoverlaAscentId = eventRepository.save(goverlaAscent).getId();
  }

  @Test
  @DisplayName("Повинен зберігати нову подію і знаходити її за ID")
  void testSaveAndFindById_NewEvent() {
    // Given
    Event newEvent = new Event();
    newEvent.setJourneyId(journeyCarpatiansHikeId);
    newEvent.setLocationId(locationCarpathiansId); // Може бути null
    newEvent.setName("Вечеря біля вогнища");
    newEvent.setDescription("Готуємо кашу та співаємо пісні.");
    newEvent.setEventDate(LocalDate.of(2024, 7, 12));
    newEvent.setEventTime(LocalTime.of(19, 30));

    // When
    Event savedEvent = eventRepository.save(newEvent);
    Optional<Event> foundEventOpt = eventRepository.findById(savedEvent.getId());

    // Then
    assertNotNull(savedEvent.getId(), "ID не повинен бути null після збереження");
    assertTrue(foundEventOpt.isPresent(), "Збережена подія має бути знайдена за ID");
    Event foundEvent = foundEventOpt.get();
    assertEquals("Вечеря біля вогнища", foundEvent.getName());
    assertEquals(journeyCarpatiansHikeId, foundEvent.getJourneyId());
    assertEquals(locationCarpathiansId, foundEvent.getLocationId());
    assertEquals(LocalDate.of(2024, 7, 12), foundEvent.getEventDate());
  }

  @Test
  @DisplayName("Повинен оновлювати існуючу подію")
  void testUpdateEvent() {
    // Given
    Event eventToUpdate = eventRepository.findById(eventGoverlaAscentId).orElseThrow();
    eventToUpdate.setName("Сходження на Говерлу (змінено)");
    eventToUpdate.setDescription("Змінений опис підкорення.");
    eventToUpdate.setEventTime(LocalTime.of(7, 30)); // Змінили час

    // When
    eventRepository.save(eventToUpdate);
    Event updatedEvent = eventRepository.findById(eventGoverlaAscentId).orElseThrow();

    // Then
    assertEquals("Сходження на Говерлу (змінено)", updatedEvent.getName());
    assertEquals("Змінений опис підкорення.", updatedEvent.getDescription());
    assertEquals(LocalTime.of(7, 30), updatedEvent.getEventTime());
  }

  @Test
  @DisplayName("Повинен знаходити всі події")
  void testFindAll() {
    // Given
    // У setUp вже створено одну подію. Створимо ще одну.
    Event anotherEvent = new Event();
    anotherEvent.setName("Спостереження за зірками");
    anotherEvent.setJourneyId(journeyCarpatiansHikeId);
    eventRepository.save(anotherEvent);

    // When
    List<Event> allEvents = eventRepository.findAll();

    // Then
    assertEquals(2, allEvents.size(), "Має бути знайдено 2 події");
  }

  @Test
  @DisplayName("Повинен знаходити всі події для певної подорожі")
  void testFindByJourneyId() {
    // Given
    // У setUp вже є одна подія для journeyCarpatiansHikeId
    // Створимо ще одну подію для цієї ж подорожі
    Event campfireEvening = new Event();
    campfireEvening.setJourneyId(journeyCarpatiansHikeId);
    campfireEvening.setName("Вечір біля вогнища");
    eventRepository.save(campfireEvening);

    // Створимо іншу подорож та подію для неї, щоб перевірити фільтрацію
    Journey otherJourney = new Journey();
    otherJourney.setUserId(userIdTestUser);
    otherJourney.setName("Інша подорож для подій");
    otherJourney = journeyRepository.save(otherJourney);
    Event otherEvent = new Event();
    otherEvent.setJourneyId(otherJourney.getId());
    otherEvent.setName("Подія в іншій подорожі");
    eventRepository.save(otherEvent);

    // When
    List<Event> eventsForHike = eventRepository.findByJourneyId(journeyCarpatiansHikeId);

    // Then
    assertEquals(2, eventsForHike.size(), "Має бути знайдено 2 події для походу в Карпати");
    assertTrue(eventsForHike.stream().anyMatch(e -> "Сходження на Говерлу".equals(e.getName())));
    assertTrue(eventsForHike.stream().anyMatch(e -> "Вечір біля вогнища".equals(e.getName())));
  }

  @Test
  @DisplayName("Повинен видаляти подію за ID")
  void testDeleteById() {
    // Given
    Long eventIdToDelete = eventGoverlaAscentId; // Подія, створена в setUp

    // When
    eventRepository.deleteById(eventIdToDelete);
    Optional<Event> deletedEventOpt = eventRepository.findById(eventIdToDelete);

    // Then
    assertFalse(deletedEventOpt.isPresent(), "Подія має бути видалена з бази даних");
  }
}
