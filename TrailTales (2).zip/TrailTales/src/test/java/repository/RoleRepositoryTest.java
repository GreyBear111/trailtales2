// src/test/java/com/trailtales/repository/RoleRepositoryTest.java
package repository;

import static org.junit.jupiter.api.Assertions.*;

import com.trailtales.config.AppConfig;
import com.trailtales.entity.Role;
import com.trailtales.entity.RoleName;
import com.trailtales.entity.User;
import com.trailtales.repository.RoleRepository;
import com.trailtales.repository.UserRepository;
import com.trailtales.util.PasswordHasher;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AppConfig.class)
@Transactional
@DisplayName("Тести для RoleRepository")
class RoleRepositoryTest {

  @Autowired private RoleRepository roleRepository;

  @Autowired private UserRepository userRepository;

  @Autowired private DataSource dataSource;

  private PasswordHasher passwordHasher = new PasswordHasher();

  private Long roleUserId;
  private Long roleAdminId;

  @BeforeEach
  void setUp() throws SQLException, IOException {
    // 1. Очищення та створення схеми
    try (Connection connection = dataSource.getConnection();
        java.sql.Statement statement = connection.createStatement()) {
      statement.execute(
          "TRUNCATE TABLE "
              + "roles, users, locations, journeys, journey_participants, events, "
              + "tags, journey_tags, photos, user_roles "
              + "RESTART IDENTITY CASCADE");

      Resource ddlResource = new ClassPathResource("ddl.sql");
      String ddlScript = ddlResource.getContentAsString(StandardCharsets.UTF_8);
      statement.execute(ddlScript);
    }

    // 2. Програмне створення ролей
    Role userRole = roleRepository.save(new Role(null, RoleName.ROLE_USER, null, null));
    roleUserId = userRole.getId();

    Role adminRole = roleRepository.save(new Role(null, RoleName.ROLE_ADMIN, null, null));
    roleAdminId = adminRole.getId();
  }

  @Test
  @DisplayName("Повинен знаходити роль за ID")
  void testFindById() {
    // When
    Optional<Role> foundRoleUserOpt = roleRepository.findById(roleUserId);
    Optional<Role> foundRoleAdminOpt = roleRepository.findById(roleAdminId);

    // Then
    assertTrue(foundRoleUserOpt.isPresent(), "Роль ROLE_USER має бути знайдена");
    assertEquals(RoleName.ROLE_USER, foundRoleUserOpt.get().getName());

    assertTrue(foundRoleAdminOpt.isPresent(), "Роль ROLE_ADMIN має бути знайдена");
    assertEquals(RoleName.ROLE_ADMIN, foundRoleAdminOpt.get().getName());
  }

  @Test
  @DisplayName("Повинен знаходити роль за назвою (RoleName)")
  void testFindByName() {
    // When
    Optional<Role> foundRoleUserOpt = roleRepository.findByName(RoleName.ROLE_USER);
    Optional<Role> foundRoleAdminOpt = roleRepository.findByName(RoleName.ROLE_ADMIN);

    // Then
    assertTrue(foundRoleUserOpt.isPresent(), "Роль ROLE_USER має бути знайдена за назвою");
    assertEquals(roleUserId, foundRoleUserOpt.get().getId());

    assertTrue(foundRoleAdminOpt.isPresent(), "Роль ROLE_ADMIN має бути знайдена за назвою");
    assertEquals(roleAdminId, foundRoleAdminOpt.get().getId());
  }

  @Test
  @DisplayName("Повинен знаходити всі ролі")
  void testFindAll() {
    // When
    List<Role> allRoles = roleRepository.findAll();

    // Then
    assertEquals(2, allRoles.size(), "Має бути знайдено 2 ролі");
    assertTrue(allRoles.stream().anyMatch(r -> r.getName() == RoleName.ROLE_USER));
    assertTrue(allRoles.stream().anyMatch(r -> r.getName() == RoleName.ROLE_ADMIN));
  }

  @Test
  @DisplayName("Повинен знаходити ролі для конкретного користувача")
  void testFindRolesByUserId() {
    // Given
    User testUser = new User();
    testUser.setUsername("role_test_user");
    testUser.setEmail("role.test@example.com");
    testUser.setPasswordHash(passwordHasher.hashPassword("password"));

    Role roleUser = roleRepository.findById(roleUserId).orElseThrow();
    Role roleAdmin = roleRepository.findById(roleAdminId).orElseThrow();
    testUser.setRoles(new HashSet<>(Set.of(roleUser, roleAdmin)));

    User savedUser = userRepository.save(testUser);

    // When
    Set<Role> foundRoles = roleRepository.findRolesByUserId(savedUser.getId());

    // Then
    assertNotNull(foundRoles);
    assertEquals(2, foundRoles.size(), "Користувач повинен мати 2 ролі");
    assertTrue(foundRoles.stream().anyMatch(r -> r.getName() == RoleName.ROLE_USER));
    assertTrue(foundRoles.stream().anyMatch(r -> r.getName() == RoleName.ROLE_ADMIN));
  }

  @Test
  @DisplayName(
      "Повинен видаляти роль (і пов'язані записи з user_roles), якщо вона не використовується")
  void testDeleteById_RoleIsDeletable() {
    // Given
    // Створюємо нову, тимчасову роль для тестування видалення,
    // щоб не видаляти основні ROLE_USER або ROLE_ADMIN, які можуть бути потрібні іншим тестам.
    // ВАЖЛИВО: RoleName має бути розширюваним, або цей тест не пройде компіляцію.
    // Якщо RoleName не розширюється, то видалення ролей взагалі не є типовою операцією.
    // Припустимо, для тесту ми можемо додати тимчасове значення до RoleName або
    // видаляємо одну з існуючих, але тоді інші тести можуть впасти, якщо вони залежать від неї.
    // Давайте спробуємо видалити ROLE_ADMIN, але тільки після того, як відв'яжемо всіх користувачів
    // від неї.

    // Створимо користувача з роллю ROLE_ADMIN
    User testUserWithAdminRole = new User();
    testUserWithAdminRole.setUsername("admin_role_holder");
    testUserWithAdminRole.setEmail("adminholder@example.com");
    testUserWithAdminRole.setPasswordHash(passwordHasher.hashPassword("password"));
    Role adminRoleToAssign = roleRepository.findById(roleAdminId).orElseThrow();
    testUserWithAdminRole.addRole(adminRoleToAssign);
    User savedUser = userRepository.save(testUserWithAdminRole);

    // Переконаємося, що користувач має цю роль
    assertTrue(
        roleRepository.findRolesByUserId(savedUser.getId()).stream()
            .anyMatch(r -> r.getId().equals(roleAdminId)),
        "Користувач повинен мати роль ROLE_ADMIN перед видаленням ролі");

    // Тепер "відв'язуємо" користувача від ролі, щоб її можна було "видалити" (інакше спрацює
    // обмеження зовнішнього ключа)
    // Ваш RoleRepository.deleteById видаляє з user_roles, що є правильним.
    // Але якщо інші користувачі ще мають цю роль, сама роль не буде видалена, якщо є обмеження.
    // У вашому випадку, onDeleteCascade на user_roles до roles, тому видалення ролі видалить
    // зв'язки.

    // When
    roleRepository.deleteById(roleAdminId);

    // Then
    Optional<Role> deletedRoleOpt = roleRepository.findById(roleAdminId);
    assertFalse(deletedRoleOpt.isPresent(), "Роль ROLE_ADMIN має бути видалена");

    // Перевіряємо, що зв'язок у user_roles також видалено для цього користувача
    Set<Role> rolesForUserAfterDelete = roleRepository.findRolesByUserId(savedUser.getId());
    assertFalse(
        rolesForUserAfterDelete.stream().anyMatch(r -> r.getId().equals(roleAdminId)),
        "Після видалення ролі ROLE_ADMIN, користувач не повинен її мати");

    // Роль ROLE_USER має залишитися
    assertTrue(roleRepository.findById(roleUserId).isPresent(), "Роль ROLE_USER має залишитися");
  }
}
